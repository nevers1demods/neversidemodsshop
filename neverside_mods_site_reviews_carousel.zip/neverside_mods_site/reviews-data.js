window.reviews = [
  {
    "name": "Константин Мур",
    "rating": 5,
    "text": "Купил сборку на заказ Medium Level за 450₽, все четко без просадки фпс, советую",
    "avatar": "assets/reviews/review-01.jpg"
  },
  {
    "name": "Александр Черницын",
    "rating": 5,
    "text": "Решил взять полное обучение на сборки, и ни капли не пожалел. Помогли с каналом, сейчас уже 400 подписчиков, всем советую",
    "avatar": "assets/reviews/review-02.jpg"
  },
  {
    "name": "Denis Nefedov",
    "rating": 5,
    "text": "Купил сборку инсайд обс, оч хорошая сборка за такой прайс",
    "avatar": "assets/reviews/review-03.jpg"
  },
  {
    "name": "Александр Миньйонов",
    "rating": 5,
    "text": "Взял приватку, не пожалел, 300+ сборок лежит как и сказали",
    "avatar": "assets/reviews/review-04.jpg"
  },
  {
    "name": "Артем Ковалев",
    "rating": 5,
    "text": "чотко быстро и круто зафиксили пнг",
    "avatar": "assets/reviews/review-05.jpg"
  },
  {
    "name": "Дмитрий Дурманнов",
    "rating": 5,
    "text": "приобрел whiterz сборку на сайте, все четко работает, советую",
    "avatar": "assets/reviews/review-06.jpg"
  },
  {
    "name": "Ильназ Рахимов",
    "rating": 5,
    "text": "Заказал сборку изи лвл, все отлично работает",
    "avatar": "assets/reviews/review-07.jpg"
  },
  {
    "name": "Самат Замалетдинов",
    "rating": 5,
    "text": "купил сборку invicta, лучшая сборка на которой играл",
    "avatar": "assets/reviews/review-08.jpg"
  },
  {
    "name": "Yokagami Ewerstairsov",
    "rating": 5,
    "text": "Лучшие сборки",
    "avatar": "assets/reviews/review-09.jpg"
  },
  {
    "name": "Суба Хардмодс",
    "rating": 5,
    "text": "Крутой сайт и канал",
    "avatar": "assets/reviews/review-10.jpg"
  }
];
