window.builds = {
  "1": {
    "title": "Сборка WHITE Estructure Beautiful forest!",
    "image": "assets/build-01.jpg",
    "features": [
      "Поддержка ENB-графики",
      "Звёздное небо",
      "Шикарный genrl",
      "FPS Boost",
      "Заменки в руки",
      "Прекрасная графика (/sw 1 /st 13)"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw 1–45",
        "text": "смена погоды"
      },
      {
        "code": "/st 1–24",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "250 ₽",
    "cardPrice": "250 ₽",
    "button": "Купить",
    "link": "https://t.me/ultimativeuser"
  },
  "2": {
    "title": "Сборка WHITE Estructura Titan edition!",
    "image": "assets/build-02.jpg",
    "features": [
      "Заменены оружия в руку",
      "Кастомное окно аутентификации",
      "Прекрасное реалистичное небо",
      "Все номера сервера (1–21) на лого",
      "Заменены звуки оружия"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw 1–45",
        "text": "смена погоды"
      },
      {
        "code": "/st 1–24",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "200 ₽",
    "cardPrice": "200 ₽",
    "button": "Купить",
    "link": "https://t.me/ultimativeuser"
  },
  "3": {
    "title": "Сборка INVICTA perfect gameplay!",
    "image": "assets/build-03.jpg",
    "features": [
      "Заменены оружия в руку",
      "Кастомное окно аутентификации",
      "Фиолетовое приятное небо",
      "Шикарный HUD под цвет неба для каптов",
      "Все номера сервера (1–21) на лого"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw 1–45",
        "text": "смена погоды"
      },
      {
        "code": "/st 1–24",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "150 ₽",
    "cardPrice": "150 ₽",
    "button": "Купить",
    "link": "https://t.me/ultimativeuser"
  },
  "4": {
    "title": "Сборка INCIDE OBS Studio",
    "image": "assets/build-04.jpg",
    "features": [
      "Поддержка ENB-графики",
      "Звёздное небо",
      "Шикарный genrl",
      "FPS Boost",
      "Заменки в руки"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw 1–45",
        "text": "смена погоды"
      },
      {
        "code": "/st 1–24",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "100 ₽",
    "cardPrice": "100 ₽",
    "button": "Купить",
    "link": "https://t.me/ultimativeuser"
  },
  "5": {
    "title": "Сборка WHITERZ crmp boyzzz!",
    "image": "assets/build-05.jpg",
    "features": [
      "Заменены иконки HUD",
      "Заменены оружия в руку",
      "Новое окно аутентификации",
      "Серое приятное небо",
      "Приятный серый HUD для каптов",
      "Все номера сервера (1–21) на лого"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw 1–45",
        "text": "смена погоды"
      },
      {
        "code": "/st 1–24",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "100 ₽",
    "cardPrice": "100 ₽",
    "button": "Купить",
    "link": "https://t.me/ultimativeuser"
  },
  "6": {
    "title": "Сборка UNIQUENESS fullrage gameplay!",
    "image": "assets/build-06.jpg",
    "features": [
      "Поддержка ENB-графики",
      "Изумительное звёздное небо",
      "Шикарный genrl",
      "FPS Boost",
      "Заменки в руки",
      "Прекрасная графика (/sw 1 /st 13)"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw 1–45",
        "text": "смена погоды"
      },
      {
        "code": "/st 1–24",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "100 ₽",
    "cardPrice": "100 ₽",
    "button": "Купить",
    "link": "https://t.me/ultimativeuser"
  },
  "7": {
    "title": "Сборка FUCKDOWN greatest of all time!",
    "image": "assets/build-07.jpg",
    "features": [
      "Приятный белый HUD",
      "Красивый фист",
      "Прекрасное оранжевое небо (/sw 18 /st 18)",
      "Все номера сервера (1–21) на лого",
      "Заменены звуки оружия"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw 1–45",
        "text": "смена погоды"
      },
      {
        "code": "/st 1–24",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "50 ₽",
    "cardPrice": "50 ₽",
    "button": "Купить",
    "link": "https://t.me/ultimativeuser"
  },
  "8": {
    "title": "Сборка RADMIR RolePlay gray edition!",
    "image": "assets/build-08.jpg",
    "features": [
      "Заменены иконки HUD",
      "Заменены ганы в руку",
      "Новое окно аутентификации",
      "Серое звёздное небо (/sw 39 /st 9)",
      "Приятный серый HUD для каптов",
      "Все номера сервера (1–21) на лого"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw",
        "text": "смена погоды"
      },
      {
        "code": "/st",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "0 ₽",
    "cardPrice": "Бесплатно",
    "button": "Скачать",
    "link": "https://t.me/neversidemods/1059"
  },
  "9": {
    "title": "Сборка xLag made happy end!",
    "image": "assets/build-09.jpg",
    "features": [
      "Поддержка ENB-графики",
      "Полностью чистая основа",
      "Шикарное облачное небо",
      "Хороший genrl",
      "FPS Boost",
      "Ярко-розовое красивое небо (/sw 2 /st 13)"
    ],
    "commands": [
      {
        "code": "/bell 1–10",
        "text": "смена колокола"
      },
      {
        "code": "/bell_vol",
        "text": "настройка громкости колокола"
      },
      {
        "code": "/pricel 1–25",
        "text": "смена прицела"
      },
      {
        "code": "/sw 1–45",
        "text": "смена погоды"
      },
      {
        "code": "/st 1–24",
        "text": "смена времени"
      },
      {
        "code": "/rd",
        "text": "настройка радаров"
      },
      {
        "code": "/rec",
        "text": "быстрый реконект вместо /q"
      }
    ],
    "price": "0 ₽",
    "cardPrice": "Бесплатно",
    "button": "Скачать",
    "link": "https://t.me/neversidemods/1052"
  }
};
